package com.iter.utils;

import com.iter.domain.Customer;
import com.iter.domain.User;
import com.iter.web.RegisterForm.RegisterFormBean;
import com.iter.web.WebBean.AddBean;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.UUID;

public class WebUtils {

    public static AddBean request2ben(HttpServletRequest request) throws ParseException {
        Enumeration<String> names = request.getParameterNames();
        AddBean bean = new AddBean();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String birthday = request.getParameter("birthday");
        Date parse = sdf.parse(birthday);
        bean.setBirthday(parse);

        bean.setId(request.getParameter("id"));
        bean.setCellphone(request.getParameter("cellphone"));
        bean.setDescription(request.getParameter("description"));
        bean.setEmail(request.getParameter("email"));
        bean.setGender(request.getParameter("gender"));
        bean.setName(request.getParameter("name"));
        bean.setPreference(request.getParameter("preference"));
        bean.setType(request.getParameter("type"));
        return bean;
    }


    public static Customer copyBean(AddBean bean, Customer customer) {
        customer.setDescription(bean.getDescription());
        customer.setType(bean.getType());
        customer.setPreference(bean.getPreference());
        customer.setEmail(bean.getEmail());
        customer.setCellphone(bean.getCellphone());
        customer.setBirthday(bean.getBirthday());
        customer.setGender(bean.getGender());
        customer.setName(bean.getName());
        customer.setId(bean.getId());
        return customer;

    }

    public static String getUUID() {
        return UUID.randomUUID().toString();
    }

    public static void copyBean(RegisterFormBean formBean, User u) {
        u.setName(formBean.getName());
        u.setPassword(formBean.getPassword());
        u.setEmail(formBean.getEmail());
        u.setSex(formBean.getSex());
        u.setIdentity(formBean.getIdentity());
    }

    public static RegisterFormBean request(HttpServletRequest request) {
        RegisterFormBean formBean = new RegisterFormBean();
        formBean.setName(request.getParameter("name"));
        formBean.setPassword(request.getParameter("password"));
        formBean.setTureName(request.getParameter("tureName"));
        formBean.setEmail(request.getParameter("email"));
        formBean.setSex(request.getParameter("sex"));
        formBean.setIdentity(request.getParameter("identity"));
        return formBean;
    }
}
