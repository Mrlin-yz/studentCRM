package com.iter.utils;

/**
 * add页面中有可变的参数：定义公开类方便维护
 */
public class Globals {
    public static String genders[] = {"男", "女"};
    public static String preferences[] = {"唱", "跳", "rap", "篮球"};
    public static String types[] = {"好学生", "坏学生", "个性学生"};
}
