package com.iter.dao;

import com.iter.domain.Teacher;
import com.iter.domain.User;

public interface UserDao {
    void add(User user);

    User finUser(String name, String password);

    boolean exitsUser(String name);

    void addTeacher(Teacher teacher);
}
