package com.iter.dao.imp;

import com.iter.dao.CustomerDao;
import com.iter.domain.Customer;
import com.iter.utils.DBUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDaoImp implements CustomerDao {

    @Override
    public void add(Customer c) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement("insert into customer values (?,?,?,?,?,?,?,?,?)");
            statement.setString(1, c.getId());
            statement.setString(2, c.getName());
            statement.setString(3, c.getGender());
            statement.setDate(4, new java.sql.Date(c.getBirthday().getTime()));
            statement.setString(5, c.getCellphone());
            statement.setString(6, c.getEmail());
            statement.setString(7, c.getPreference());
            statement.setString(8, c.getType());
            statement.setString(9, c.getDescription());

            int i = statement.executeUpdate();
        } catch (SQLException e) {
            new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(connection, statement, resultSet);
        }
    }

    @Override
    public void delete(String id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();

            statement = connection.prepareStatement("delete from customer where id = ?");
            statement.setString(1, id);
            int i = statement.executeUpdate();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(connection, statement, resultSet);
        }
    }

    @Override
    public void upDate(Customer c) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement("update customer set name=?,gender=?,birthday=?,cellphone=?,email=?,preference=?,type=?,description=? where id=?");
            statement.setString(1, c.getName());
            statement.setString(2, c.getGender());
            statement.setDate(3, new Date(c.getBirthday().getTime()));
            statement.setString(4, c.getCellphone());
            statement.setString(5, c.getEmail());
            statement.setString(6, c.getPreference());
            statement.setString(7, c.getType());
            statement.setString(8, c.getDescription());
            statement.setString(9, c.getId());

            int i = statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(connection, statement, resultSet);
        }


    }

    @Override
    public Customer find(String id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement("select * from customer where id=?");
            statement.setString(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Customer customer = new Customer();

                customer.setId(resultSet.getString("id"));
                customer.setName(resultSet.getString("name"));
                customer.setGender(resultSet.getString("gender"));
                customer.setBirthday(resultSet.getDate("birthday"));
                customer.setCellphone(resultSet.getString("cellphone"));
                customer.setEmail(resultSet.getString("email"));
                customer.setPreference(resultSet.getString("preference"));
                customer.setType(resultSet.getString("type"));
                customer.setDescription(resultSet.getString("description"));
                return customer;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(connection, statement, resultSet);
        }
    }

    @Override
    public List<Customer> getALL() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Customer> list = new ArrayList<>();
        try {
            connection = DBUtils.getConnection();
            statement = connection.prepareStatement("select * from customer");
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Customer customer = new Customer();
                customer.setId(resultSet.getString("id"));
                customer.setName(resultSet.getString("name"));
                customer.setGender(resultSet.getString("gender"));
                customer.setBirthday(resultSet.getDate("birthday"));
                customer.setCellphone(resultSet.getString("cellphone"));
                customer.setEmail(resultSet.getString("email"));
                customer.setPreference(resultSet.getString("preference"));
                customer.setType(resultSet.getString("type"));
                customer.setDescription(resultSet.getString("description"));
                list.add(customer);
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(connection, statement, resultSet);
        }
    }
}
