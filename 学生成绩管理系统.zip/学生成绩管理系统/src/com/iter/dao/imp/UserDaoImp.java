package com.iter.dao.imp;

import com.iter.dao.UserDao;
import com.iter.domain.Teacher;
import com.iter.domain.User;
import com.iter.utils.DBUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * CREATE DATABASE day09
 * USE day09;
 * <p>
 * CREATE TABLE USER(
 * id VARCHAR(20) PRIMARY KEY,
 * uname VARCHAR(20)NOT NULL,
 * upassword VARCHAR(20)NOT NULL,
 * email VARCHAR(20),
 * sex INT
 * )
 * INSERT INTO USER VALUES('001','zhangsan','123','zs@qq.com','1');
 */
public class UserDaoImp implements UserDao {
    @Override
    public void add(User user) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            preparedStatement = connection.prepareStatement("insert into user(name,password,email,sex,identity) values (?,?,?,?,?)");
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getPassword());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getSex());
            preparedStatement.setString(5, user.getIdentity());

            int i = preparedStatement.executeUpdate();

            if (i > 0) {
                System.out.println("yes");
            } else {
                System.out.println("no");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(connection, preparedStatement, resultSet);
        }

    }

    @Override
    public User finUser(String name, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            preparedStatement = connection.prepareStatement("select * from user where name=? and password=?");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();
            User u = new User();

            while (resultSet.next()) {
                u.setId(resultSet.getInt("id"));
                u.setName(resultSet.getString("name"));
                u.setPassword(resultSet.getString("password"));
                u.setEmail(resultSet.getString("email"));
                u.setSex(resultSet.getString("sex"));
                u.setIdentity(resultSet.getString("identity"));

             /*   System.out.println(resultSet.getString("uname"));
                System.out.println(resultSet.getString("upassword"));
                System.out.println(resultSet.getString("email"));
                System.out.println(resultSet.getString("sex"));*/
            }
            return u;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(connection, preparedStatement, resultSet);
        }
        return null;
    }

    @Override
    public boolean exitsUser(String name) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            preparedStatement = connection.prepareStatement("select * from user where name=? ");
            preparedStatement.setString(1, name);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(connection, preparedStatement, resultSet);
        }
        return false;
    }

    @Override
    public void addTeacher(Teacher teacher) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DBUtils.getConnection();
            preparedStatement = connection.prepareStatement("insert into teacher(id,name,age) values (?,?,?)");
            preparedStatement.setString(1, teacher.getId());
            preparedStatement.setString(2, teacher.getName());
            preparedStatement.setString(3, teacher.getAge());

            int i = preparedStatement.executeUpdate();

            if (i > 0) {
                System.out.println("yes");
            } else {
                System.out.println("no");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtils.closeConnection(connection, preparedStatement, resultSet);
        }

    }
}
