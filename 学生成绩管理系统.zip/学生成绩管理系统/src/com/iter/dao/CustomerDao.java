package com.iter.dao;

import com.iter.domain.Customer;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDao {
    //增删改查 getAll
    void add(Customer c);

    void delete(String id) ;

    void upDate(Customer c) ;

    Customer find(String id);

     List<Customer> getALL();
}
