package com.iter.web.controller;

import com.iter.domain.User;
import com.iter.web.LoginForm.LoginFormBena;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ServletloginControllor")
public class ServletloginControllor extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {




        //校验数据
        LoginFormBena lf = new LoginFormBena();
        User user = lf.LoginFormBena(request);
        if (user == null) {
            request.getRequestDispatcher("\\WEB-INF\\jsp\\login.jsp").forward(request,response);
            return;
        }

        System.out.println(user);

        System.out.println(user.getName());
        System.out.println(user.getPassword());

        if (null != (user.getName())) {
            //欢迎
            request.setAttribute("user", user);
            switch (user.getIdentity()){
                case "1":request.getRequestDispatcher("\\WEB-INF\\jsp\\adminFinder.jsp").forward(request, response);
                    break;
                case "2":request.getRequestDispatcher("\\WEB-INF\\jsp\\teacherFinder.jsp").forward(request, response);
                    break;
                case "3":request.getRequestDispatcher("\\WEB-INF\\jsp\\studentFinder.jsp").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("\\WEB-INF\\jsp\\Welcom.jsp").forward(request, response);
            System.out.println("yes");
        } else {
            //重新登录
            request.getRequestDispatcher("\\WEB-INF\\jsp\\login.jsp").forward(request, response);
            System.out.println("no");
        }


    }
}
