package com.iter.web.controller;

import com.iter.dao.CustomerDao;
import com.iter.dao.imp.CustomerDaoImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ServletRemoveSer")
public class ServletRemoveSer extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
//        response.getWriter().write("remove");
        System.out.println(id);
        CustomerDao dao = new CustomerDaoImp();
        dao.delete(id);

        request.setAttribute("message","删除"+id+"成功");
        request.getRequestDispatcher("\\WEB-INF\\jsp\\message.jsp").forward(request,response);
    }
}
