package com.iter.web.controller;

import com.iter.domain.User;
import com.iter.service.serviceImp.LoginImpl;
import com.iter.utils.WebUtils;
import com.iter.web.RegisterForm.RegisterFormBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(name = "ServletregisterController")
public class ServletregisterController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //这里通过request接收到用户填写的注册信息了
    /*    Enumeration<String> names = request.getParameterNames();
        while (names.hasMoreElements()) {
            String s = names.nextElement();
            System.out.println(s + "===========" + request.getParameter(s));
        }*/

        //创建一个封装form表单的实体类,作用校验表单数据,里面提供校验表单的方法cache
        //1对用户提交的数据进行合法性校验判断
        RegisterFormBean formBean = WebUtils.request(request);
        boolean b = formBean.cacheForm();
//        System.out.println(b);//ture

        //2如果校验失败，跳回表单页面，回写校验失败信息
        if (!b) {
            //把form对象存到request域里面带过去
            request.setAttribute("form", formBean);
            request.getRequestDispatcher("\\WEB-INF\\jsp\\regist.jsp").forward(request, response);
            return;
        }
        //3如果校验成功，调用service层。处理注册请求
        //怎么获取userBean? 表单from里面已经存了user信息 思考，实现拷贝
        //user id属性怎么解决？--- webUtils提供id生成方法 （uuid）
        User u = new User();
        try {
//            u.setId(Integer.parseInt(request.getParameter("id")));
            WebUtils.copyBean(formBean, u);//拷贝bean
            LoginImpl service = new LoginImpl();
            //考虑注册可能出现的异常信息
            service.register(u);
        } catch (Exception e) {
            //4.如果service处理不成功，并且不成功的原因，是因为注册用户已存在，则跳回到注册页面，显示用户已存在的信息
            request.setAttribute("massage", "注册用户名已存在");
            request.getRequestDispatcher("\\WEB-INF\\jsp\\regist.jsp").forward(request, response);
            return;
        }
        //6.如果service处理成功，跳转到网站的全局消息显示页面，为用户注册成功的消息
//        response.getWriter().write("welcom");

//        re.sendRedirect("\\WEB-INF\\jsp\\login.jsp");
        request.getRequestDispatcher("\\WEB-INF\\jsp\\login.jsp").forward(request, response);

    }
}
