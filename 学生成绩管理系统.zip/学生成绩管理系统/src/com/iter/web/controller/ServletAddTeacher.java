package com.iter.web.controller;

import com.iter.dao.imp.UserDaoImp;
import com.iter.domain.Customer;
import com.iter.domain.Teacher;
import com.iter.service.CustomerService;
import com.iter.service.serviceImp.CustomerServiceImp;
import com.iter.utils.Globals;
import com.iter.utils.WebUtils;
import com.iter.web.WebBean.AddBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;

@WebServlet(name = "ServletAddTeacher")
public class ServletAddTeacher extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");

      /*  String[] types = request.getParameterValues("preference");
        for (String type : types) {
            System.out.println(type);
        }*/
//        boolean cache = true;
//        AddBean bean = null;
//        try {
//            bean = WebUtils.request2ben(request);
//            cache = bean.cache();
//        } catch (ParseException e) {
//            e.printStackTrace();
//            request.setAttribute("message", "提交数据有误");
//            request.getRequestDispatcher("\\WEB-INF\\jsp\\message.jsp").forward(request, response);
//        }
//
//        if (!cache) {
//            //校验不通过 返回首页
//            request.getRequestDispatcher("\\WEB-INF\\jsp\\add.jsp").forward(request, response);
//        }
        //通过执行添加
//        CustomerService sc = new CustomerServiceImp();
//        Customer customer = new Customer();
//        Customer copyBean = WebUtils.copyBean(bean, customer);
//
//        sc.addCustomer(copyBean);

        UserDaoImp userDaoImp = new UserDaoImp();
        Teacher teacher = new Teacher();
        teacher.setId(request.getParameter("id"));
        teacher.setName(request.getParameter("name"));
        teacher.setAge(request.getParameter("age"));
        userDaoImp.addTeacher(teacher);

        request.setAttribute("message", "添加老师" + teacher.getName() + "成功");

        request.getRequestDispatcher("\\WEB-INF\\jsp\\message.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //专业术语 视图，与上一个项目相比这里少了个跳转的servlet，
        // 因为客户机提交是get请求。提交的表单是post请求，所有get这里做页面跳转，post处理请求
        request.setAttribute("genders", Globals.genders);
        request.setAttribute("preferences", Globals.preferences);
        request.setAttribute("types", Globals.types);
        request.getRequestDispatcher("\\WEB-INF\\jsp\\addteacher.jsp").forward(request, response);

    }
}
