package com.iter.web.controller;

import com.iter.dao.CustomerDao;
import com.iter.dao.imp.CustomerDaoImp;
import com.iter.domain.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ServletfindTo")
public class ServletfindTo extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");

        CustomerDao dao =new CustomerDaoImp();
        Customer customer = dao.find(id);
//        response.getWriter().write(customer.getId());
        request.setAttribute("cus",customer);
        request.getRequestDispatcher("\\WEB-INF\\jsp\\FindTo.jsp").forward(request,response);
    }
}
