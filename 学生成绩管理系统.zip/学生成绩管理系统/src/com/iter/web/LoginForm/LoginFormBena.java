package com.iter.web.LoginForm;


import com.iter.dao.UserDao;
import com.iter.dao.imp.UserDaoImp;
import com.iter.domain.User;

import javax.servlet.http.HttpServletRequest;

public class LoginFormBena {

    public User LoginFormBena(HttpServletRequest request) {
        String name = request.getParameter("name");
        String password = request.getParameter("password");

        UserDao u = new UserDaoImp();
        boolean b = u.exitsUser(name);
        if (!b) {
            return null;
        }
        return u.finUser(name, password);

    }
}
