package com.iter.web.WebBean;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddBean {
    private String gender;
    private String id;
    private Date birthday;
    private String preference;
    private String name;
    private String cellphone;
    private String email;
    private String type;
    private String description;
    private Map errorMap = new HashMap();

    //校验
    public boolean cache() {
        boolean isok = true;

        if (gender == null || gender.trim().equals("")) {
            isok = false;
            errorMap.put("gender", "性别不能为空");
        }

        if (id == null || id.trim().equals("")) {
            isok = false;
            errorMap.put("id", "id不能为空");
        }

        if (preference == null || preference.trim().equals("")) {
            isok = false;
            errorMap.put("per", "pre不能为空");
        }

        if (email == null || email.trim().equals("")) {
            isok = false;
            errorMap.put("id", "id不能为空");
        }
        if (cellphone == null || cellphone.trim().equals("")) {
            isok = false;
            errorMap.put("cell", "cell不能为空");
        }
        if (type == null || type.trim().equals("")) {
            isok = false;
            errorMap.put("id", "type不能为空");
        }


        return isok;
    }


    public AddBean() {
    }

    public AddBean(String gender, String id, Date birthday, String preference, String name, String cellphone, String email, String type, String description) {
        this.gender = gender;
        this.id = id;
        this.birthday = birthday;
        this.preference = preference;
        this.name = name;
        this.cellphone = cellphone;
        this.email = email;
        this.type = type;
        this.description = description;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getPreference() {
        return preference;
    }

    public void setPreference(String preference) {
        this.preference = preference;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
