package com.iter.web.RegisterForm;

import java.util.HashMap;

public class RegisterFormBean {
    private String name;
    private String password;
    private String tureName;
    private String email;
    private String sex;
    private String identity;
    //map集合保存校验失败的消息
    private HashMap<String, String> errorMap = new HashMap<>();

    public RegisterFormBean() {

    }


    /**
     * 校验文本:(规范)
     * 用户名不能为空:3-8位字母
     * 密码不能为空:3-8位数字
     * 确认密码不能为空,要与密码一致
     * 电子邮箱不能为空,格式要合法
     *
     * @return
     */
    public boolean cacheForm() {
        boolean isOk = true;

        if (null == name || name.trim().equals("")) {
            isOk = false;
            errorMap.put("name", "用户名不能为空");
        } else {
            if (!name.matches("[A-Za-z]{3,8}")) {
                isOk = false;
                errorMap.put("name", "用户名3-8位字母");
            }
        }
        //密码校验
        if (null == password || password.trim().equals("")) {
            isOk = false;
            errorMap.put("password", "密码不能为空");
        } else {
            if (!password.matches("\\d{3,8}")) {
                isOk = false;
                errorMap.put("password", "密码3-8位数字  ");
            }
        }

        //确认密码校验
        if (null == tureName || tureName.trim().equals("")) {
            isOk = false;
            errorMap.put("tureName", "确认密码不能为空");
        } else {
            if (!password.equals(tureName)) {
                isOk = false;
                errorMap.put("tureName", "两次密码不一致");
            }
        }

        //校验邮箱
        if (null == email || email.trim().equals("")) {
            isOk = false;
            errorMap.put("email", "邮箱不能为空");
        }
   /*     else {
            //这里没有校验,后期加上
            if (!email.matches("[A-Za-z]{3,8}")) {
                isOk = false;
                errorMap.put("email", "邮箱不符合规范");
            }
        }*/

        //校验性别
        if (null == sex || sex.trim().equals("")) {
            isOk = false;
            errorMap.put("sex", "性别不能为空");
        } else {
            if (!(sex.equals("0") || sex.equals("1"))) {
                isOk = false;
                errorMap.put("sex", "性别请正确填写");
            }
        }
        return isOk;
    }

    public RegisterFormBean(String name, String password, String tureName, String email, String sex, String identity, HashMap<String, String> errorMap) {
        this.name = name;
        this.password = password;
        this.tureName = tureName;
        this.email = email;
        this.sex = sex;
        this.identity = identity;
        this.errorMap = errorMap;
    }

    public HashMap<String, String> getErrorMap() {
        return errorMap;
    }

    public void setErrorMap(HashMap<String, String> errorMap) {
        this.errorMap = errorMap;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTureName() {
        return tureName;
    }

    public void setTureName(String tureName) {
        this.tureName = tureName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    @Override
    public String toString() {
        return "RegisterFormBean{" +
                "name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", tureName='" + tureName + '\'' +
                ", email='" + email + '\'' +
                ", sex='" + sex + '\'' +
                ", identity='" + identity + '\'' +
                ", errorMap=" + errorMap +
                '}';
    }
}
