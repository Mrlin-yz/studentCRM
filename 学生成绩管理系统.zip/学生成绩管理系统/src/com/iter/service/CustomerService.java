package com.iter.service;

import com.iter.domain.Customer;

import java.util.List;

public interface CustomerService {
    void addCustomer(Customer c);

    void deleteCustomer(String id);

    void upDateCustomer(Customer c);

    Customer findCustomer(String id);

    List<Customer> getALLCustomer();
}
