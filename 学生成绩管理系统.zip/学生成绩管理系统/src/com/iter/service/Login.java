package com.iter.service;

import com.iter.domain.User;

public interface Login {
    //对web层提供注册服务
    void register(User userBena) throws Exception;

    //对web层提供登录服务
    User login(String name, String password);
}
