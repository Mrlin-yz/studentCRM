package com.iter.service.serviceImp;

import com.iter.dao.CustomerDao;
import com.iter.dao.imp.CustomerDaoImp;
import com.iter.domain.Customer;
import com.iter.service.CustomerService;

import java.util.List;

public class CustomerServiceImp implements CustomerService {

    private CustomerDao dao = new CustomerDaoImp();//工厂模式解耦

    @Override
    public void addCustomer(Customer c) {
        dao.add(c);
    }

    @Override
    public void deleteCustomer(String id) {
        dao.delete(id);
    }

    @Override
    public void upDateCustomer(Customer c) {
        dao.upDate(c);
    }

    @Override
    public Customer findCustomer(String id) {
        return dao.find(id);
    }

    @Override
    public List<Customer> getALLCustomer() {
        return dao.getALL();
    }
}
