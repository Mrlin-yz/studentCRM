package com.iter.service.serviceImp;

import com.iter.dao.UserDao;
import com.iter.dao.imp.UserDaoImp;
import com.iter.domain.User;
import com.iter.service.Login;

//对web层提供所有的业务服务
public class LoginImpl implements Login {

    private UserDao dao = new UserDaoImp();

    //对web层提供注册服务
    @Override
    public void register(User userBena) throws Exception {
        //先判断当前要注册的用户是否存在
        boolean b = dao.exitsUser(userBena.getName());
        if (b) {
            throw new Exception("用户已存在");
        } else {
            //md5加密
            dao.add(userBena);
        }
    }


    //对web层提供登录服务
    @Override
    public User login(String name, String password) {
        //md5 解密
        return dao.finUser(name, password);
    }
}

