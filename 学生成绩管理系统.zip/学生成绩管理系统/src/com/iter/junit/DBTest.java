package com.iter.junit;

//import org.junit.Test;


public class DBTest {
//
//    @Test//is ok
//    public void dbAdd() {
//        try {
//            Connection connection = DBUtils.getConnection();
////            Statement statement = connection.createStatement();
////            ResultSet resultSet = statement.executeQuery("select *from customer");
//
//            Customer c = new Customer("002", "zhangsan", "nv", new Date(), "128748", "admin@qq.com", "make love", "se", "good");
//            System.out.println(c);
//
//            PreparedStatement statement = connection.prepareStatement("insert into customer values (?,?,?,?,?,?,?,?,?)");
//            statement.setString(1, c.getId());
//            statement.setString(2, c.getName());
//            statement.setString(3, c.getGender());
//            statement.setDate(4, new java.sql.Date(c.getBirthday().getTime()));
//            statement.setString(5, c.getCellphone());
//            statement.setString(6, c.getEmail());
//            statement.setString(7, c.getPreference());
//            statement.setString(8, c.getType());
//            statement.setString(9, c.getDescription());
//
//            int i = statement.executeUpdate();
//
//
//            ResultSet resultSet = statement.executeQuery("select *from customer");
//            while (resultSet.next()) {
//                System.out.println(resultSet.getString(1) + resultSet.getString(2));
//            }
//
//            DBUtils.closeConnection(connection, statement, resultSet);
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//    @Test
//    public void add() {
//        CustomerDao dao = new CustomerDaoImp();
//        Customer c = new Customer("003", "love", "男", new Date(), "128748", "admin@qq.com", "make love", "se", "good");
//
//        dao.add(c);
//    }
//
//    @Test//IS OK
//    public void findUser() {
//        CustomerDao c = new CustomerDaoImp();
//
//        Customer customer = c.find("003");
//        System.out.println(customer);
//
//    }
//
//    @Test
//    public void getAll() {
//        CustomerDao customerDao = new CustomerDaoImp();
//
//        List<Customer> all = customerDao.getALL();
////        all.get()
//        for (Customer customer : all) {
//            System.out.println(customer);
//        }
//
//    }
//
//    @Test
//    public void delet() {
//        CustomerDao customerDao = new CustomerDaoImp();
//
//        customerDao.delete("004");
//
//
//    }
//
//    @Test
//    public void update() {
//        Customer c = new Customer("003", "xxxx", "asd", new Date(), "128748", "admin@qq.com", "make love", "se", "good");
//
//        CustomerDao dao = new CustomerDaoImp();
////        Customer customer = com.find("003");
////        System.out.println(customer);
//
//        dao.upDate(c);
//    /*    System.out.println("-------------------");
//        Customer customer2 = com.find("003");
//        System.out.println(customer2);*/
//    }
}